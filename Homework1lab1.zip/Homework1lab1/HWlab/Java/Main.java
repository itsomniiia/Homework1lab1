
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Card> cards = new ArrayList<>();

        cards.add(new Card("Is water wet?", "Yes", true));
        cards.add(new Card("Does the sun rise at night?", "No", false));
        cards.add(new Card("Is fire hot?", "Yes", true));
        cards.add(new Card("Can humans breathe underwater?", "No", false));
        cards.add(new Card("Is ice cold?", "Yes", false));
        cards.add(new Card("Do birds fly?", "Yes", true));

        CardOrganizer organizer = new RecentMistakesFirstSorter();
        List<Card> sortedCards = organizer.organize(cards);

        System.out.println("Cards:");
        for (Card c : sortedCards) {
            System.out.println(c);

        }
    }
}