public class Card {

    private String question;
    private String answer;
    private boolean correctInLastRound;

    public Card(String question, String answer, boolean correctInLastRound) {
        this.question = question;
        this.answer = answer;
        this.correctInLastRound = correctInLastRound;
    }

    public boolean wasCorrectInLastRound() {
        return correctInLastRound;
    }

    public String getQuestion() {
        return question;
    }

    @Override
    public String toString() {
        return question + " = " + answer + " , Your Answer is: " + correctInLastRound;
    }
}
