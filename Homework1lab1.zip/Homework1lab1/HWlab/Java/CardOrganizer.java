import java.util.List;

public interface CardOrganizer {
    List<Card> organize(List<Card> cards);
}
