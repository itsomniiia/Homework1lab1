import { Card } from "./Card";
import { newRecentMistakesFirstSorter } from "./newRecentMistakesFirstSorter";

const cards: Card[] = [];

cards.push(new Card("Is water wet?", "Yes", true));
cards.push(new Card("Does the sun rise at night?", "No", false));
cards.push(new Card("Is fire hot?", "Yes", true));
cards.push(new Card("Can humans breathe underwater?", "No", false));

const organizer = new newRecentMistakesFirstSorter();
const sortedCards = organizer.organize(cards);

console.log("Cards:");
for (const c of sortedCards) {
  console.log(c.toString());
}
