export class Card {
  question: string;
  answer: string;
  correctInLastRound: boolean;

  constructor(question: string, answer: string, correctInLastRound: boolean) {
    this.question = question;
    this.answer = answer;
    this.correctInLastRound = correctInLastRound;
  }

  wasCorrectInLastRound(): boolean {
    return this.correctInLastRound;
  }

  toString(): string {
    return `${this.question} = ${this.answer} , Your Answer is: ${this.correctInLastRound}`;
  }
}
